from santa.LinMHelper import LinMHelperApp

root = LinMHelperApp()
print('主程式結束。')