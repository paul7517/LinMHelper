def detectTeamEnabled(img):
    # check point 1
    intX=int(10.25 * img.width / 100)
    intY1=int(23.88 * img.height / 100)
    intY2=int(25.83 * img.height / 100)    
    
    cnt = 0
    total = intY2 - intY1
    th = int(total / 2)
    for intY in range(intY1,intY2):
        rgb = getPixel(img, intX, intY, 255)        
        #print('RGB:%d,%d,%d' %(th,rgb[1],rgb[2]))        
        if((rgb[0] > 220) and (rgb[1] > 220) and rgb[2] > 220):
           cnt+=1

    isC1Matched = cnt > th
    #print('cnt:',cnt)

    # check point 2    
    intX=int(27.55 * img.width / 100)
    intY1=int(22.80 * img.height / 100)
    intY2=int(25.95 * img.height / 100)

    cnt = 0    
    for intY in range(intY1,intY2):
        rgb = getPixel(img, intX, intY, 255)        
        #print('RGB:%d,%d,%d' %(th,rgb[1],rgb[2]))        
        if((rgb[0] > 220) and (rgb[1] > 220) and rgb[2] > 220):
           cnt+=1

    isC2Matched = cnt > 3
    #print('cnt:',cnt)
    return isC1Matched and isC2Matched, 0

def detectTeamEnabled_(img):
    isC1Matched = comparePointRGBSum(img, 10.25, 24.28, 700, 770, 255)
    isC2Matched = comparePointRGBSum(img, 27.55, 23.85, 700, 770, 255)  

    return isC1Matched and isC2Matched , 0

def detectTeamPositionAvalible(img,teamPosition):            
    x=17.2
    
    position = teamPosition
    if(position >= 1):  position-=1
    y=37.7 + 8.8*position

            
    matched = comparePointRGBSum(img, x, y, 700, 770,0)
    
    return matched

def detectItemSkillPanelOpened(img):
    intX=int(71.23 * img.width / 100)
    intY1=int(20.88 * img.height / 100)
    intY2=int(61.43 * img.height / 100)
    
    cnt = 0
    total = intY2-intY1
    for intY in range(intY1,intY2):
        if(compareRGB(getPixel(img, intX, intY, -1), (25,40) , (15,30) , (10,25)) 
           or compareRGB(getPixel(img, intX, intY, -1), (15,25) , (15,25) , (15,25))):
           cnt+=1
    #print(cnt / total * 100)    
    return cnt / total * 100 >= 72.0        

#判斷血條
def detectHPPercent(img,teamPosition,rgbValue):
    cnt = 0
    status_count = 0
    intX1 = int(5.7 * img.width / 100)
    intX2 = int(14.1 * img.width / 100)
    
    shiftUnit = 0
    if(teamPosition != None):
        shiftUnit = int(teamPosition)
    if(shiftUnit >=1): #0代表沒組隊，但還是要判斷
        shiftUnit -=1

    yPercent = 2.8 + 35.38 + shiftUnit * 8.8
    
    y=int(yPercent * img.height /100)
    for x in range(intX1,intX2):
       if(comparePointRGB(img, x, y, (137,205), (0,15),(0,15), -1)): # -1為不畫標示在圖上，才不會影響到後面的其他判斷
           cnt+=1
       if(comparePointRGB(img, x, y, (4, 25), (40, 55), (0, 15), -1)): # 判斷中毒  isPosion          
            status_count+=1
            
    hpPercent = int(cnt / (intX2-intX1) * 100)


    #print('SP: %d' %status_count)
        
    return hpPercent, status_count > 0


#判斷MP條
def detectMPPercent(img,teamPosition,rgbValue):
    cnt = 0
    intX1 = int(5.7 * img.width / 100)
    intX2 = int(14.1 * img.width / 100)
    
    shiftUnit = 0
    if(teamPosition != None):
        shiftUnit = int(teamPosition)
    if(shiftUnit >=1 ): #0代表沒組隊，但還是要判斷
        shiftUnit -= 1
        
    yPercent = 2.8 + 37.00 + shiftUnit * 8.8
    
    y=int(yPercent * img.height /100)
    for x in range(intX1,intX2):
        if(comparePointRGB(img, x, y, (0,21), (60,125),(110,202),rgbValue)):
            cnt+=1
    
    mpPercent = int(cnt / (intX2-intX1) * 100)
    return mpPercent

#判斷是否攻擊中
def detectIsAttack(img):
    cnt = 0
    intX1 = int(83.8 * img.width / 100)
    intX2 = int(87 * img.width / 100)

    y = int(69.07 * img.height / 100)    
    for x in range(intX1,intX2):        

        rgb = getPixel(img, x, y, 255)
        #print('RGB:%d,%d,%d' %(rgb[0],rgb[1],rgb[2]))
        isAttck = (rgb[0] - rgb[1] > 64) or (rgb[0] - rgb[2] > 90)
        
        if(isAttck):
            cnt+=1
        y+=1
    
    attRate = cnt / (intX2 - intX1 + 1) * 100 
    #print('attRate:',attRate)

    return attRate >= 17

#判斷是否被攻擊
def detectIsAttacked(img):
    cnt = 0
    area =0
    intX1 = int(93* img.width / 100)
    intX2 = int(94* img.width / 100)

    Y0 = 75.5
    intY1 = int(Y0 * img.height / 100)
    intY2 = int((Y0+1.5) * img.height / 100)
    
    for x in range(intX1,intX2):        
        for y in range(intY1, intY2):
            rgb = getPixel(img, x, y, 255)
            #print('RGB:%d,%d,%d' %(rgb[0],rgb[1],rgb[2]))
            isAttcked = (rgb[0] > 220) and (rgb[0] - rgb[1] > 64)
            
            if(isAttcked):
                cnt+=1
            area+=1
    
    attRate1 = cnt / area * 100 
    #print('attRate1: ',attRate1)
###################################
    cnt = 0
    intX1 = int(0.5 * img.width / 100)
    intX2 = int(5.0 * img.width / 100)
    y = int(2.0*img.height / 100)
    for x in range(intX1,intX2):        
        rgb = getPixel(img, x, y, 255)
        isAttcked = (rgb[0] - rgb[1] > 48) or (rgb[0] - rgb[2] > 90) 

    if(isAttcked):
        cnt+=1

    attedRate2 = cnt / (intX2 - intX1 + 1) * 100
   # print('attedRate2:',attedRate2)
     

    return (attRate1 > 50) and (attedRate2 > 2)

#判斷是否被攻擊
def detectIsAttacked2(img):
    cnt = 0
    intX1 = int(0.5 * img.width / 100)
    intX2 = int(5.0 * img.width / 100)
    y = int(2.0*img.height / 100)
    for x in range(intX1,intX2):        
        rgb = getPixel(img, x, y, 255)
        isAttcked = (rgb[0] - rgb[1] > 48) or (rgb[0] - rgb[2] > 90) 

    if(isAttcked):
        cnt+=1

    attedRate = cnt / (intX2 - intX1 + 1) * 100
    print('attedRate_:',attedRate)
    return attedRate > 2

#比較單點的RGB總合
def comparePointRGBSum(img,x,y,rgb_bound1,rgb_bound2,overrideValue):
    intX , intY = convertIntPosition(img,x,y)

  #  z = 2
 #   for x in range(int(intX-z),int(intX+z)):
  #      for y in range(int(intY-z), int(intY+z)):            
  #          rgb = getPixel(img, x, y, 255)
           # print('comparePointRGBSum - RGB:%d,%d,%d' %(rgb[0],rgb[1],rgb[2]))
    
    r,g,b = getPixel(img, intX, intY, overrideValue)
    rgbSum = r + g + b
        
    return rgbSum >= rgb_bound1 and rgbSum <= rgb_bound2

#比對單點的R、G、B範圍
def comparePointRGB(img,x,y,r_range,g_range,b_range,rgbValue):
    intX , intY = convertIntPosition(img,x,y)

    rgb = getPixel(img, intX, intY, rgbValue)
    rst = compareRGB(rgb, r_range, g_range, b_range)
    
    if(rgbValue== -2):
        if(not rst):
            print('RGB:%d,%d,%d , Range is %d~%d,%d~%d,%d~%d' %(rgb[0],rgb[1],rgb[2],r_range[0],r_range[1],g_range[0],g_range[1],b_range[0],b_range[1]))
    return rst

def convertIntPosition(img,fX,fY):
    if isinstance(fX,float) and isinstance(fY,float):
        intX , intY = int(fX * img.width / 100) , int(fY * img.height / 100) 
    else:
        intX , intY = fX , fY
    
    return intX , intY

#取得img裡的pixel rgb (主要用以在圖上mark)
def getPixel(img,intX,intY,rgbValue):
    rgb = img.getpixel((intX,intY))
    
    #work around
    if(rgbValue == -2):
        print(rgb)
    
    if(rgbValue >= 0):
        img.putpixel((intX,intY),(0,rgbValue,0))
    return rgb

#比對RGB是否有在range裡
def compareRGB(rgb , r_range,g_range,b_range):
    return (rgb[0] >= r_range[0] and r_range[1]) and (rgb[1] >=g_range[0] and rgb[1] <= g_range[1]) and (rgb[2] >= b_range[0] and rgb[2] <= b_range[1])


#Draw squares
def drawSquares(img, targer_point, squares_size):    
    t_x = targer_point[0] / 1280.0 * img.width
    t_y = targer_point[1] / 720.0 * img.height
    
    for x in range (int(t_x - squares_size), int(t_x + squares_size)):
        for y in range (int(t_y - squares_size), int(t_y + squares_size)):
            getPixel(img, x, y, 255)

    return 0



    
